"use client";

import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import { Eye, Save } from "lucide-react";

import { saveQuestionAction } from "@/features/question-bank/actions";
import { QuestionMathRenderer } from "@/features/question-bank/components/question-math-renderer";
import { QuestionMediaPreview } from "@/features/question-bank/components/question-media-preview";
import type { SelectOption } from "@/lib/master-data/queries";
import { cn } from "@/lib/utils";

type QuestionFormOption = SelectOption & {
  subject_id?: string;
  content?: string | null;
  media_url?: string | null;
  media_type?: string | null;
};

type EditableQuestion = {
  id?: string | null;
  school_id?: string | null;
  subject_id?: string | null;
  category_id?: string | null;
  stimulus_id?: string | null;
  type?: string | null;
  difficulty?: string | null;
  content?: string | null;
  explanation?: string | null;
  point?: number | string | null;
  is_active?: boolean | null;
  question_stimuli?: {
    title?: string | null;
    content?: string | null;
    media_url?: string | null;
    media_type?: string | null;
  } | null;
  question_options?: Array<{
    option_label: string;
    option_text: string;
    is_correct: boolean;
    order_number: number;
  }> | null;
  question_attachments?: Array<{
    media_type: string;
    url: string;
    file_name?: string | null;
    caption?: string | null;
    order_number: number;
  }> | null;
};

type QuestionFormProps = {
  editable?: EditableQuestion | null;
  schoolId: string;
  subjects: SelectOption[];
  categories: QuestionFormOption[];
  stimuli: QuestionFormOption[];
  defaultSubjectId?: string;
  defaultCategoryId?: string;
};

const labels = ["A", "B", "C", "D", "E"] as const;
const requiredLabels = ["A", "B", "C", "D"] as const;
const steps = [
  "Informasi",
  "Pertanyaan",
  "Jawaban",
  "Stimulus & Media",
  "Lanjutan",
] as const;
type StimulusMode = "none" | "existing" | "new";

function optionValue(question: EditableQuestion | null | undefined, label: string) {
  return (
    question?.question_options?.find((item) => item.option_label === label)
      ?.option_text ?? ""
  );
}

function correctOption(question: EditableQuestion | null | undefined) {
  return (
    question?.question_options?.find((option) => option.is_correct)
      ?.option_label ?? ""
  );
}

function firstAttachment(question: EditableQuestion | null | undefined) {
  return [...(question?.question_attachments ?? [])].sort(
    (a, b) => a.order_number - b.order_number,
  )[0];
}

function Panel({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-xl border border-[#E2E8F0] bg-white p-5 shadow-sm">
      <div className="mb-4">
        <h2 className="text-base font-semibold text-[#0F172A]">{title}</h2>
        {description ? (
          <p className="mt-1 text-sm leading-6 text-[#64748B]">{description}</p>
        ) : null}
      </div>
      {children}
    </section>
  );
}

function Accordion({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <details className="rounded-xl border border-[#E2E8F0] bg-white p-4 shadow-sm">
      <summary className="cursor-pointer text-sm font-semibold text-[#0F172A]">
        {title}
      </summary>
      <div className="mt-4">{children}</div>
    </details>
  );
}

function FieldLabel({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="grid gap-1.5 text-sm text-[#0F172A]">
      <span className="font-medium">{label}</span>
      {children}
    </label>
  );
}

function ErrorList({ errors }: { errors: string[] }) {
  if (errors.length === 0) {
    return null;
  }

  return (
    <div className="rounded-xl border border-[#EF4444]/30 bg-[#EF4444]/10 p-3 text-sm text-[#EF4444]">
      <div className="font-medium">Periksa lagi sebelum menyimpan:</div>
      <ul className="mt-2 list-disc space-y-1 pl-5">
        {errors.map((error) => (
          <li key={error}>{error}</li>
        ))}
      </ul>
    </div>
  );
}

export function QuestionForm({
  editable,
  schoolId,
  subjects,
  categories,
  stimuli,
  defaultSubjectId,
  defaultCategoryId,
}: QuestionFormProps) {
  const attachment = firstAttachment(editable);
  const initialSubjectId =
    editable?.subject_id ?? defaultSubjectId ?? subjects[0]?.value ?? "";
  const [step, setStep] = useState(0);
  const [subjectId, setSubjectId] = useState(initialSubjectId);
  const [type, setType] = useState(editable?.type ?? "multiple_choice");
  const [content, setContent] = useState(editable?.content ?? "");
  const [explanation, setExplanation] = useState(editable?.explanation ?? "");
  const [point, setPoint] = useState(String(editable?.point ?? "1"));
  const [correct, setCorrect] = useState(correctOption(editable));
  const [options, setOptions] = useState<Record<string, string>>({
    A: optionValue(editable, "A"),
    B: optionValue(editable, "B"),
    C: optionValue(editable, "C"),
    D: optionValue(editable, "D"),
    E: optionValue(editable, "E"),
  });
  const [stimulusId, setStimulusId] = useState(editable?.stimulus_id ?? "");
  const [stimulusMode, setStimulusMode] = useState<StimulusMode>(
    editable?.stimulus_id ? "existing" : "none",
  );
  const [newStimulusTitle, setNewStimulusTitle] = useState("");
  const [newStimulusContent, setNewStimulusContent] = useState("");
  const [newStimulusMediaUrl, setNewStimulusMediaUrl] = useState("");
  const [newStimulusMediaType, setNewStimulusMediaType] = useState("");
  const [attachmentMediaType, setAttachmentMediaType] = useState(
    attachment?.media_type ?? "image",
  );
  const [attachmentUrl, setAttachmentUrl] = useState(attachment?.url ?? "");
  const [attachmentCaption, setAttachmentCaption] = useState(
    attachment?.caption ?? "",
  );
  const [errors, setErrors] = useState<string[]>([]);
  const [showPreview, setShowPreview] = useState(false);

  const filteredCategories = useMemo(
    () =>
      categories.filter(
        (category) => !category.subject_id || category.subject_id === subjectId,
      ),
    [categories, subjectId],
  );
  const filteredStimuli = useMemo(
    () =>
      stimuli.filter(
        (stimulus) => !stimulus.subject_id || stimulus.subject_id === subjectId,
      ),
    [stimuli, subjectId],
  );
  const selectedStimulus =
    filteredStimuli.find((stimulus) => stimulus.value === stimulusId) ??
    (editable?.stimulus_id === stimulusId
      ? {
          value: stimulusId,
          label: editable.question_stimuli?.title ?? "Stimulus",
          content: editable.question_stimuli?.content,
          media_url: editable.question_stimuli?.media_url,
          media_type: editable.question_stimuli?.media_type,
        }
      : null);
  const isMultipleChoice = type === "multiple_choice";

  function validate() {
    const nextErrors: string[] = [];

    if (!subjectId) nextErrors.push("Mapel wajib dipilih.");
    if (!content.trim()) nextErrors.push("Pertanyaan wajib diisi.");
    if (!Number(point) || Number(point) <= 0) {
      nextErrors.push("Poin wajib lebih dari 0.");
    }

    if (isMultipleChoice) {
      const emptyLabels = requiredLabels.filter((label) => !options[label].trim());
      if (emptyLabels.length > 0) {
        nextErrors.push("Pilihan ganda wajib mengisi opsi A, B, C, dan D.");
      }
      if (!correct) nextErrors.push("Pilih satu jawaban benar.");
      if (correct === "E" && !options.E.trim()) {
        nextErrors.push("Opsi E wajib diisi jika dipilih sebagai jawaban benar.");
      }
    }

    if (stimulusMode === "existing" && !stimulusId) {
      nextErrors.push("Pilih stimulus yang akan digunakan.");
    }

    if (
      stimulusMode === "new" &&
      (!newStimulusTitle.trim() ||
        (!newStimulusContent.trim() && !newStimulusMediaUrl.trim()))
    ) {
      nextErrors.push(
        "Stimulus baru wajib memiliki judul dan isi bacaan atau URL media.",
      );
    }

    setErrors(nextErrors);
    return nextErrors.length === 0;
  }

  return (
    <form
      action={saveQuestionAction}
      className="grid gap-5"
      onSubmit={(event) => {
        if (!validate()) {
          event.preventDefault();
        }
      }}
    >
      <input type="hidden" name="id" defaultValue={editable?.id ?? ""} />
      <input type="hidden" name="school_id" value={schoolId} />
      <input type="hidden" name="status" value="draft" />
      <input type="hidden" name="stimulus_mode" value={stimulusMode} />

      <ErrorList errors={errors} />

      <div className="rounded-xl border border-[#E2E8F0] bg-white p-3 shadow-sm">
        <div className="grid gap-2 sm:grid-cols-5">
          {steps.map((label, index) => (
            <button
              key={label}
              type="button"
              onClick={() => setStep(index)}
              className={cn(
                "rounded-xl border px-3 py-2 text-left text-sm transition",
                step === index
                  ? "border-[#2563EB] bg-[#2563EB] text-white"
                  : "border-[#E2E8F0] bg-white text-[#64748B] hover:bg-[#F8FAFC]",
              )}
            >
              <span className="block text-xs opacity-80">Step {index + 1}</span>
              <span className="font-medium">{label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className={step === 0 ? "block" : "hidden"}>
        <Panel
          title="Informasi Soal"
          description="Pilih metadata utama soal sebelum menulis pertanyaan."
        >
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <FieldLabel label="Mapel">
              <select
                name="subject_id"
                value={subjectId}
                onChange={(event) => {
                  setSubjectId(event.target.value);
                  setStimulusId("");
                  setStimulusMode("none");
                }}
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              >
                <option value="">Pilih mapel</option>
                {subjects.map((subject) => (
                  <option key={subject.value} value={subject.value}>
                    {subject.label}
                  </option>
                ))}
              </select>
            </FieldLabel>
            <FieldLabel label="Kategori">
              <select
                name="category_id"
                defaultValue={editable?.category_id ?? defaultCategoryId ?? ""}
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              >
                <option value="">Tanpa kategori</option>
                {filteredCategories.map((category) => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>
            </FieldLabel>
            <FieldLabel label="Tipe Soal">
              <select
                name="type"
                value={type}
                onChange={(event) => setType(event.target.value)}
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              >
                <option value="multiple_choice">Pilihan ganda</option>
                <option value="essay">Essay</option>
              </select>
            </FieldLabel>
            <FieldLabel label="Difficulty">
              <select
                name="difficulty"
                defaultValue={editable?.difficulty ?? "medium"}
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </FieldLabel>
            <FieldLabel label="Poin">
              <input
                name="point"
                type="number"
                min="0.01"
                step="0.01"
                value={point}
                onChange={(event) => setPoint(event.target.value)}
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              />
            </FieldLabel>
          </div>
        </Panel>
      </div>

      <div className={step === 1 ? "block" : "hidden"}>
        <Panel title="Pertanyaan" description="Editor utama dibuat besar agar fokus ke isi soal.">
          <textarea
            name="content"
            value={content}
            onChange={(event) => setContent(event.target.value)}
            placeholder="Tulis konten soal"
            className="min-h-72 w-full rounded-xl border border-[#E2E8F0] px-4 py-3 text-sm leading-7"
          />
        </Panel>
      </div>

      <div className={step === 2 ? "block" : "hidden"}>
        <Panel
          title="Jawaban"
          description={
            isMultipleChoice
              ? "Isi opsi A-D. Opsi E tersedia jika dibutuhkan."
              : "Soal essay tidak membutuhkan pilihan jawaban."
          }
        >
          {isMultipleChoice ? (
            <div className="grid gap-4">
              <FieldLabel label="Jawaban Benar">
                <select
                  name="correct_option"
                  value={correct}
                  onChange={(event) => setCorrect(event.target.value)}
                  className="max-w-sm rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
                >
                  <option value="">Pilih jawaban benar</option>
                  {labels.map((label) => (
                    <option key={label} value={label}>
                      Jawaban {label}
                    </option>
                  ))}
                </select>
              </FieldLabel>
              <div className="grid gap-3 md:grid-cols-2">
                {labels.map((label) => (
                  <label key={label} className="flex gap-3 text-sm">
                    <span className="mt-3 w-6 font-semibold text-[#2563EB]">
                      {label}
                    </span>
                    <textarea
                      name={`option_${label}`}
                      value={options[label]}
                      onChange={(event) =>
                        setOptions((current) => ({
                          ...current,
                          [label]: event.target.value,
                        }))
                      }
                      placeholder={`Opsi ${label}${label === "E" ? " (opsional)" : ""}`}
                      className="min-h-24 flex-1 rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
                    />
                  </label>
                ))}
              </div>
            </div>
          ) : (
            <div className="rounded-xl border border-[#E2E8F0] bg-[#F8FAFC] p-4 text-sm text-[#64748B]">
              Jawaban essay akan dinilai melalui alur koreksi. Gunakan pembahasan
              atau catatan koreksi di pengaturan lanjutan jika diperlukan.
            </div>
          )}
        </Panel>
      </div>

      <div className={step === 3 ? "block" : "hidden"}>
        <Accordion title="Stimulus dan Media">
          <div className="grid gap-5">
            <div className="grid gap-2 text-sm md:grid-cols-3">
              {[
                ["none", "Tanpa stimulus"],
                ["existing", "Pilih stimulus"],
                ["new", "Buat stimulus baru"],
              ].map(([value, label]) => (
                <label
                  key={value}
                  className="flex items-center gap-2 rounded-xl border border-[#E2E8F0] px-3 py-2"
                >
                  <input
                    type="radio"
                    name="stimulus_mode_choice"
                    value={value}
                    checked={stimulusMode === value}
                    onChange={() => {
                      const nextMode = value as StimulusMode;
                      setStimulusMode(nextMode);
                      if (nextMode !== "existing") setStimulusId("");
                    }}
                  />
                  {label}
                </label>
              ))}
            </div>

            {stimulusMode === "existing" ? (
              <FieldLabel label="Stimulus">
                <select
                  name="stimulus_id"
                  value={stimulusId}
                  onChange={(event) => setStimulusId(event.target.value)}
                  className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
                >
                  <option value="">Pilih stimulus</option>
                  {filteredStimuli.map((stimulus) => (
                    <option key={stimulus.value} value={stimulus.value}>
                      {stimulus.label}
                    </option>
                  ))}
                </select>
              </FieldLabel>
            ) : null}

            {stimulusMode === "new" ? (
              <div className="grid gap-3 md:grid-cols-2">
                <input
                  name="new_stimulus_title"
                  value={newStimulusTitle}
                  onChange={(event) => setNewStimulusTitle(event.target.value)}
                  placeholder="Judul stimulus baru"
                  className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
                />
                <select
                  name="new_stimulus_media_type"
                  value={newStimulusMediaType}
                  onChange={(event) => setNewStimulusMediaType(event.target.value)}
                  className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
                >
                  <option value="">Text</option>
                  <option value="image">Image</option>
                  <option value="audio">Audio</option>
                  <option value="video">Video</option>
                  <option value="file">File/PDF</option>
                  <option value="link">Link</option>
                </select>
                <input
                  name="new_stimulus_media_url"
                  value={newStimulusMediaUrl}
                  onChange={(event) => setNewStimulusMediaUrl(event.target.value)}
                  placeholder="URL media stimulus"
                  className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm md:col-span-2"
                />
                <textarea
                  name="new_stimulus_content"
                  value={newStimulusContent}
                  onChange={(event) => setNewStimulusContent(event.target.value)}
                  placeholder="Teks stimulus atau bacaan"
                  className="min-h-28 rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm md:col-span-2"
                />
              </div>
            ) : null}

            <div className="grid gap-3 border-t border-[#E2E8F0] pt-5 md:grid-cols-2">
              <select
                name="attachment_media_type"
                value={attachmentMediaType}
                onChange={(event) => setAttachmentMediaType(event.target.value)}
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              >
                <option value="image">Gambar</option>
                <option value="audio">Audio</option>
                <option value="video">Video</option>
                <option value="file">File/PDF</option>
                <option value="link">Link</option>
              </select>
              <input
                name="attachment_file_name"
                defaultValue={attachment?.file_name ?? ""}
                placeholder="Nama file/link"
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
              />
              <input
                name="attachment_url"
                value={attachmentUrl}
                onChange={(event) => setAttachmentUrl(event.target.value)}
                placeholder="https://..."
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm md:col-span-2"
              />
              <input
                name="attachment_caption"
                value={attachmentCaption}
                onChange={(event) => setAttachmentCaption(event.target.value)}
                placeholder="Caption media"
                className="rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm md:col-span-2"
              />
            </div>
          </div>
        </Accordion>
      </div>

      <div className={step === 4 ? "block" : "hidden"}>
        <Accordion title="Pengaturan Lanjutan">
          <div className="grid gap-4">
            <textarea
              name="explanation"
              value={explanation}
              onChange={(event) => setExplanation(event.target.value)}
              placeholder="Pembahasan atau catatan koreksi"
              className="min-h-32 rounded-xl border border-[#E2E8F0] px-3 py-2 text-sm"
            />
            <label className="flex items-center gap-2 text-sm">
              <input
                name="is_active"
                type="checkbox"
                defaultChecked={editable?.is_active ?? true}
              />
              Status Aktif
            </label>
          </div>
        </Accordion>
      </div>

      <div className="flex flex-col gap-3 rounded-xl border border-[#E2E8F0] bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setStep((current) => Math.max(0, current - 1))}
            disabled={step === 0}
            className="rounded-xl border border-[#E2E8F0] px-4 py-2 text-sm text-[#0F172A] transition hover:bg-[#F8FAFC] disabled:opacity-50"
          >
            Sebelumnya
          </button>
          <button
            type="button"
            onClick={() => setStep((current) => Math.min(steps.length - 1, current + 1))}
            disabled={step === steps.length - 1}
            className="rounded-xl border border-[#E2E8F0] px-4 py-2 text-sm text-[#0F172A] transition hover:bg-[#F8FAFC] disabled:opacity-50"
          >
            Berikutnya
          </button>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShowPreview(true)}
            className="inline-flex items-center gap-2 rounded-xl border border-[#E2E8F0] px-4 py-2 text-sm text-[#0F172A] transition hover:bg-[#F8FAFC]"
          >
            <Eye className="size-4" />
            Preview
          </button>
          <button className="inline-flex items-center gap-2 rounded-xl bg-[#2563EB] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#1D4ED8]">
            <Save className="size-4" />
            {editable ? "Simpan Draft" : "Simpan Draft"}
          </button>
        </div>
      </div>

      {showPreview ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4">
          <div className="max-h-[88vh] w-full max-w-3xl overflow-auto rounded-xl bg-white p-5 shadow-xl">
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold text-[#0F172A]">Preview Soal</h2>
              <button
                type="button"
                onClick={() => setShowPreview(false)}
                className="rounded-xl border border-[#E2E8F0] px-3 py-1.5 text-sm"
              >
                Tutup
              </button>
            </div>
            <div className="space-y-4 text-sm">
              {stimulusMode !== "none" ? (
                <div className="rounded-xl border border-dashed border-[#E2E8F0] p-4">
                  <div className="font-medium">
                    {newStimulusTitle || selectedStimulus?.label || "Stimulus/Bacaan"}
                  </div>
                  <QuestionMathRenderer
                    content={
                      stimulusMode === "new"
                        ? newStimulusContent
                        : selectedStimulus?.content
                    }
                    className="mt-2 text-[#64748B]"
                  />
                  <QuestionMediaPreview
                    mediaType={
                      stimulusMode === "new"
                        ? newStimulusMediaType
                        : selectedStimulus?.media_type
                    }
                    url={
                      stimulusMode === "new"
                        ? newStimulusMediaUrl
                        : selectedStimulus?.media_url
                    }
                    title={newStimulusTitle || selectedStimulus?.label}
                    className="mt-3"
                  />
                </div>
              ) : null}
              {content ? (
                <QuestionMathRenderer content={content} className="leading-7" />
              ) : (
                <div className="text-[#64748B]">Pertanyaan akan tampil di sini.</div>
              )}
              {attachmentUrl ? (
                <QuestionMediaPreview
                  mediaType={attachmentMediaType}
                  url={attachmentUrl}
                  caption={attachmentCaption}
                />
              ) : null}
              {isMultipleChoice ? (
                <div className="grid gap-2">
                  {labels
                    .filter((label) => label !== "E" || options.E.trim())
                    .map((label) => (
                      <div
                        key={label}
                        className="flex gap-2 rounded-xl border border-[#E2E8F0] px-3 py-2"
                      >
                        <span className="font-semibold">{label}.</span>
                        <span className="flex-1">
                          {options[label] ? (
                            <QuestionMathRenderer content={options[label]} />
                          ) : (
                            `Opsi ${label}`
                          )}
                        </span>
                        {correct === label ? (
                          <span className="text-xs font-medium text-[#22C55E]">
                            Benar
                          </span>
                        ) : null}
                      </div>
                    ))}
                </div>
              ) : (
                <div className="rounded-xl bg-[#F8FAFC] p-3 text-[#64748B]">
                  Soal essay tidak memakai pilihan jawaban.
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </form>
  );
}
